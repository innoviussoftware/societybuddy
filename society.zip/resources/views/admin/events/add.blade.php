@extends('layouts.admin')

@section('content')
  
<section class="content-header">
  <h1>
    
    <small>Event</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="{{ route('admin.dashboard') }}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="{{ route('admin.societies.index') }}">Societies</a></li>
    <li><a href="{{ route('admin.societies.edit', $society->id) }}">{{ $society->name }}</a></li>
    <li><a href="{{ route('admin.societies.events.index', $society->id) }}">Event</a></li>
    <li><a href="#">Add</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <form action="{{ route('admin.societies.events.store', $society->id) }}" method="post" enctype="multipart/form-data">
        @csrf

        <div class="box-header">
          <h3 class="box-title">Add Event</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Building</label>
                  <select id="multiple-checkboxes" class="form-control select2 " name="building_id[]" id="building" required data-placeholder="Select a Building" multiple="multiple">

                  @foreach($buildings as $b)

                    <option value="{{ $b->id }}" {{ ($b->id == old('building_id')) ? "selected" : "" }} >{{ $b->name }}</option>
                  @endforeach
                </select>
              </div>
              
            
              <div class="form-group">
                <label >Type</label>
                <input type="text" name="event_type" class="form-control" placeholder="Enter Type" value="{{ old('event_type') }}" required>
              </div>
              <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" class="form-control" placeholder="Enter Title" value="{{ old('title') }}" required>
              </div>
              <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" placeholder="Enter Description" name="description" required>{{ old('description') }}</textarea>
              </div>
             
            </div>
            <div class="col-md-6">
              
            
              <div class="form-group">
                <label >Start Date</label>
                <input type="text" name="startdate" class="form-control datepicker" placeholder="Enter Startdate" value="{{ old('title') }}" required autocomplete="off" required="" id="startdate">
              </div>
              <div class="form-group">
                <label>Start Time</label>
                <input type="text" name="starttime" class="form-control timepicker" placeholder="Enter Starttime" value="{{ old('description') }}" required autocomplete="off" required="">
              </div>
              <div class="form-group">
                <label>End Date</label>
                <input type="text" name="enddate" class="form-control datepicker" placeholder="Enter Enddate"  value="{{ old('viewtill') }}" required autocomplete="off" required="" id="enddate">
              </div>
              <div class="form-group">
                <label>End Time</label>
                <input type="text" name="endtime" class="form-control timepicker" placeholder="Enter Endtime" value="{{ old('description') }}" required autocomplete="off" required="">
              </div>
              <div class="form-group">
                <label>Attachment</label>
                <input type="file" name="attachment" class="form-control">
              </div>
             
            </div>
          </div>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a href="{{ route('admin.societies.events.index', $society->id) }}" class="btn btn-default">Cancel</a>
        </div>
      </form>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
@endsection
@section('custom_js')
<script src="{{ env('APP_URL') }}/admin_assets/bower_components/select2/dist/js/select2.full.min.js"></script>

<script>
$(document).ready(function (){
  $('.select2').select2({
    multiple: true,
  })
   // $('#multiple-checkboxes').multiselect({
   //        includeSelectAllOption: true,
   //      });


  $("body").on('change','#building',function (){
    var id  = $(this).val();
    getFlats(id);
  });

  // $('.datepicker').datepicker({
  //     autoclose: true,
  //      format: 'dd/mm/yyyy'
  //   })

  $('.timepicker').timepicker({
      showInputs: false,
    });

  $("#startdate").datepicker({
        numberOfMonths: 2,
        
    });

  $("#enddate").datepicker({ 
        numberOfMonths:2
        
    });  

});

</script>
@endsection
