<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('societybuddy');
})->name('index');

Route::get('/about', function () {
    return view('front.about');
})->name('about');

Route::get('/contact', function () {
    return view('front.contact');
})->name('contact');

Auth::routes();


Route::post('/contact', 'Admin\MailController@sendfeedback');

Route::get('/home', 'HomeController@index')->name('home');

Route::name('admin.')->prefix('admin')->middleware(['auth'])->group(function () {
  Route::get('/', function(){
    return redirect('admin/dashboard');
  });
  Route::get('/dashboard', 'Admin\DashboardController@index')->name('dashboard');

  Route::get('/cities', 'Admin\CityController@index')->middleware(['role:admin|sub_admin'])->middleware(['role:admin|sub_admin'])->name('cities.index');
  Route::get('/cities/add', 'Admin\CityController@add')->middleware(['role:admin|sub_admin'])->name('cities.add');
  Route::post('/cities/store', 'Admin\CityController@store')->middleware(['role:admin|sub_admin'])->name('cities.store');
  Route::get('/cities/edit/{id}', 'Admin\CityController@edit')->middleware(['role:admin|sub_admin'])->name('cities.edit');
  Route::patch('/cities/update/{id}', 'Admin\CityController@update')->middleware(['role:admin|sub_admin'])->name('cities.update');
  Route::get('/cities/delete/{id}', 'Admin\CityController@delete')->middleware(['role:admin|sub_admin'])->name('cities.delete');
  Route::get('/cities/array/', 'Admin\CityController@cityArray')->middleware(['role:admin|sub_admin'])->name('cities.array');

  Route::get('/areas', 'Admin\AreaController@index')->middleware(['role:admin|sub_admin'])->name('areas.index');
  Route::get('/areas/add', 'Admin\AreaController@add')->middleware(['role:admin|sub_admin'])->name('areas.add');
  Route::post('/areas/store', 'Admin\AreaController@store')->middleware(['role:admin|sub_admin'])->name('areas.store');
  Route::get('/areas/edit/{id}', 'Admin\AreaController@edit')->middleware(['role:admin|sub_admin'])->name('areas.edit');
  Route::patch('/areas/update/{id}', 'Admin\AreaController@update')->middleware(['role:admin|sub_admin'])->name('areas.update');
  Route::get('/areas/delete/{id}', 'Admin\AreaController@delete')->middleware(['role:admin|sub_admin'])->name('areas.delete');
  Route::get('/areas/array/', 'Admin\AreaController@Array')->middleware(['role:admin|sub_admin'])->name('areas.array');
  Route::get('/areas/byCity/{city_id}', 'Admin\AreaController@areaByCity')->middleware(['role:admin|sub_admin'])->name('areas.bycity');

  Route::get('/guardes', 'Admin\GuardController@index')->middleware(['role:admin|sub_admin|society_admin'])->name('guardes.index');
  Route::get('/guardes/add', 'Admin\GuardController@add')->middleware(['role:admin|sub_admin|society_admin'])->name('guardes.add');
  Route::post('/guardes/store', 'Admin\GuardController@store')->middleware(['role:admin|sub_admin|society_admin'])->name('guardes.store');
  Route::get('/guardes/edit/{id}', 'Admin\GuardController@edit')->middleware(['role:admin|sub_admin|society_admin'])->name('guardes.edit');
  Route::patch('/guardes/update/{id}', 'Admin\GuardController@update')->middleware(['role:admin|sub_admin|society_admin'])->name('guardes.update');
  Route::get('/guardes/delete/{id}', 'Admin\GuardController@delete')->middleware(['role:admin|sub_admin|society_admin'])->name('guardes.delete');
  Route::get('/guardes/array/', 'Admin\GuardController@Array')->middleware(['role:admin|sub_admin|society_admin'])->name('guardes.array');

  Route::get('/societies', 'Admin\SocietyController@index')->middleware(['role:admin|sub_admin'])->name('societies.index');
  Route::get('/societies/add', 'Admin\SocietyController@add')->middleware(['role:admin|sub_admin'])->name('societies.add');
  Route::post('/societies/store', 'Admin\SocietyController@store')->middleware(['role:admin|sub_admin'])->name('societies.store');
  Route::get('/societies/edit/{id}', 'Admin\SocietyController@edit')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.edit');
  Route::get('/societies/edit/{id}/buildings', 'Admin\SocietyController@editBuildings')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.editBuildings');
  Route::patch('/societies/update/{id}', 'Admin\SocietyController@update')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.update');
  Route::get('/societies/delete/{id}', 'Admin\SocietyController@delete')->middleware(['role:admin|sub_admin'])->name('societies.delete');
  Route::get('/societies/array/', 'Admin\SocietyController@Array')->middleware(['role:admin|sub_admin'])->name('societies.array');

  Route::get('/societies/{id}/buildings/add', 'Admin\SocietyController@addBuildings')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.buildings.add');
  Route::post('/societies/{society_id}/buildings/store', 'Admin\SocietyController@storeBuildings')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.buildings.store');
  Route::get('/societies/{society_id}/buildings/edit/{building_id}', 'Admin\SocietyController@editBuildings')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.buildings.edit');
  Route::patch('/societies/{society_id}/buildings/update/{building_id}', 'Admin\SocietyController@updateBuildings')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.buildings.update');
  Route::get('/societies/{society_id}/delete/buildings/{building_id}', 'Admin\SocietyController@deleteBuildings')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.buildings.delete');
  Route::get('/societies/{society_id}/array/buildings', 'Admin\SocietyController@ArrayBuildings')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.arrayBuildings');

  Route::get('/societies/{society_id}/AdminUsers', 'Admin\SocietyController@indexAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.adminusers.index');
  Route::get('/societies/{society_id}/array/adminusers', 'Admin\SocietyController@ArrayAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.arrayAdminusers');
  Route::get('/societies/{society_id}/adminusers/add', 'Admin\SocietyController@addAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.adminusers.add');
  Route::post('/societies/{society_id}/adminusers/store', 'Admin\SocietyController@storeAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.adminusers.store');
  Route::get('/societies/{society_id}/adminusers/edit/{user_id}', 'Admin\SocietyController@editAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.adminusers.edit');
  Route::patch('/societies/{society_id}/adminusers/update/{user_id}', 'Admin\SocietyController@updateAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.adminusers.update');
  Route::get('/societies/{society_id}/delete/adminusers/{user_id}', 'Admin\SocietyController@deleteAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.adminusers.delete');
  Route::post('/societies/{society_id}/adminusers/store', 'Admin\SocietyController@storeAdminUsers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.adminusers.store');

  Route::get('/societies/{society_id}/members', 'Admin\SocietyController@indexMembers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.members.index');
  Route::get('/societies/{society_id}/array/members', 'Admin\SocietyController@ArrayMembers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.arrayMembers');
  Route::get('/societies/{society_id}/members/add', 'Admin\SocietyController@addMembers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.members.add');
  Route::post('/societies/{society_id}/members/store', 'Admin\SocietyController@storeMembers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.members.store');
  Route::get('/societies/{society_id}/members/edit/{member_id}', 'Admin\SocietyController@editMembers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.members.edit');
  Route::patch('/societies/{society_id}/members/update/{member_id}', 'Admin\SocietyController@updateMembers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.members.update');
  Route::get('/societies/{society_id}/delete/members/{user_id}', 'Admin\SocietyController@deleteMembers')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.members.delete');
  Route::get('/societies/flats/byBuilding/{building_id}', 'Admin\SocietyController@flatsByBuilding');

  Route::get('/societies/{society_id}/commitees', 'Admin\SocietyController@indexCommitees')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.commitees.index');
  Route::get('/societies/{society_id}/array/commitees', 'Admin\SocietyController@ArrayCommitees')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.arrayCommitees');
  Route::get('/societies/{society_id}/commitees/edit/', 'Admin\SocietyController@editCommitees')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.commitees.edit');
  Route::patch('/societies/{society_id}/commitees/update/', 'Admin\SocietyController@updateCommitees')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.commitees.update');


  Route::get('/societies/{society_id}/notices', 'Admin\NoticeController@index')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.notices.index');
  Route::get('/societies/{society_id}/array/notices', 'Admin\NoticeController@Array')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.arrayNotice');
  Route::get('/societies/{society_id}/notices/add', 'Admin\NoticeController@addNotices')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.notices.add');
  Route::post('/societies/{society_id}/notices/store', 'Admin\NoticeController@store')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.notices.store');
  Route::get('/societies/{society_id}/notices/edit/{notice_id}', 'Admin\NoticeController@edit')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.notices.edit');
  Route::patch('/societies/{society_id}/notices/update/{member_id}', 'Admin\NoticeController@update')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.notices.update');
  Route::get('/societies/{society_id}/delete/notices/{user_id}', 'Admin\NoticeController@delete')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.notices.delete');
  Route::get('/societies/{society_id}/notices/notify/{notice_id}', 'Admin\NoticeController@notify')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.notices.notify');



  Route::get('/societies/{society_id}/circulars', 'Admin\CircularController@index')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.circulars.index');
  Route::get('/societies/{society_id}/array/circulars', 'Admin\CircularController@Array')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.arrayCircular');
  Route::get('/societies/{society_id}/circulars/add', 'Admin\CircularController@addCirculars')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.circulars.add');
  Route::post('/societies/{society_id}/circulars/store', 'Admin\CircularController@store')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.circulars.store');
  Route::get('/societies/{society_id}/circulars/edit/{notice_id}', 'Admin\CircularController@edit')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.circulars.edit');
  Route::patch('/societies/{society_id}/circulars/update/{member_id}', 'Admin\CircularController@update')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.circulars.update');
  Route::get('/societies/{society_id}/delete/circulars/{user_id}', 'Admin\CircularController@delete')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.circulars.delete');
  Route::get('/societies/{society_id}/circulars/notify/{notice_id}', 'Admin\CircularController@notify')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.circulars.notify');

  Route::get('/societies/{society_id}/events', 'Admin\EventController@index')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.events.index');
  Route::get('/societies/{society_id}/array/events', 'Admin\EventController@Array')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.arrayEvents');
  Route::get('/societies/{society_id}/events/add', 'Admin\EventController@addEvents')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.events.add');
  Route::post('/societies/{society_id}/events/store', 'Admin\EventController@store')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.events.store');
  Route::get('/societies/{society_id}/events/edit/{notice_id}', 'Admin\EventController@edit')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.events.edit');
  Route::patch('/societies/{society_id}/events/update/{member_id}', 'Admin\EventController@update')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.events.update');
  Route::get('/societies/{society_id}/delete/events/{user_id}', 'Admin\EventController@delete')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.events.delete');
  Route::get('/societies/{society_id}/events/notify/{notice_id}', 'Admin\EventController@notify')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.events.notify');



  // Route::get('/societies/{society_id}/commitees/add', 'Admin\SocietyController@addCommitees')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.commitees.add');
  // Route::post('/societies/{society_id}/commitees/store', 'Admin\SocietyController@storeCommitees')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.commitees.store');
  // Route::get('/societies/{society_id}/delete/commitees/{user_id}', 'Admin\SocietyController@deleteCommitees')->middleware(['role:admin|sub_admin|society_admin'])->name('societies.commitees.delete');

});
