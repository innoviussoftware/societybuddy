<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::post('API/login', 'UserController@localeconv()gin');





Route::namespace('API')->group(function () {
    Route::post('verifyemail', 'GuardController@emailExists');

	Route::post('loginotp', 'UserController@login_opt');
	Route::post('register', 'UserController@register');
	Route::post('get/city', 'SocietyController@getcity');
    Route::post('get/area', 'SocietyController@getarea');
    Route::post('get/society', 'SocietyController@getsociety');
    Route::post('get/building', 'SocietyController@getbuilding');
    Route::post('get/flat', 'SocietyController@getflat');
    Route::post('get/flat2', 'SocietyController@getflat2');

    Route::post('guardlogin','GuardController@guardlogin');
    Route::post('guestentry','GuardController@addguestentry');
    Route::post('currentvisitor', 'GuardController@currentVisitorList');
    Route::post('allvisitor', 'GuardController@allvisitorList');
    Route::post('InOut', 'GuardController@InoutVisitor');

    Route::post('logout', 'UserController@logout');
    Route::post('guard_logout', 'GuardController@guardLogout');

});

Route::middleware('auth:api')->prefix('user')->namespace('API')->group(function () {
	Route::post('addnotice','NoticeController@addnotice');
    Route::post('editnotice','NoticeController@editNotice');
    Route::post('getnotice','NoticeController@getNotice');
    Route::post('deletenotice','NoticeController@deleteNotice');

    Route::post('addevent','EventController@addevent');
    Route::post('editevent','EventController@editEvent');
    Route::post('getevent','EventController@getEvent');
    Route::post('deleteevent','EventController@deleteEvent');

    Route::post('addcircular','CircularController@addcircular');
    Route::post('editcircular','CircularController@editCircular');
    Route::post('getcircular','CircularController@getCircular');
    Route::post('deletecircular','CircularController@deleteCircular');

    //Route::post('guardlogin','GuardController@guardlogin');
    //Route::post('guestentry','GuardController@addguestentry');
    Route::post('acceptreject','GuardController@acceptorreject');

    Route::post('me', 'UserController@me');
    Route::post('addfamilymember', 'UserController@addfamilymember');
    Route::post('updatefamilymember', 'UserController@updatefamilymember');
    Route::post('getfamilymember', 'UserController@getFamilyMember');

    Route::post('guestlist', 'UserController@GuestList');
    Route::post('addFrequentEntry', 'GuardController@addFrequentEntry');

    Route::post('updateprofile', 'UserController@updateProfile');

});

// Route::middleware('auth:api')->namespace('API')->group(function () {
// 	    Route::post('me', 'UserController@me');
// });


Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});