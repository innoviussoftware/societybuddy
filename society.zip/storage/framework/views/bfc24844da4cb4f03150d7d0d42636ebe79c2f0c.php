<?php if (\Entrust::hasRole(['admin','sub_admin'])) : ?>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Copyright &copy; 2019 <a href="<?php echo e(env('APP_URL')); ?>/admin"><?php echo e(env('APP_NAME')); ?></a>.</strong> All rights reserved.
  </footer>
<?php endif; // Entrust::hasRole ?>

<?php if (\Entrust::hasRole('society_admin')) : ?>
  <footer class="main-footer" style="margin-left:0px;">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Copyright &copy; 2019 <a href="<?php echo e(env('APP_URL')); ?>/admin"><?php echo e(env('APP_NAME')); ?></a>.</strong> All rights reserved.
  </footer>
<?php endif; // Entrust::hasRole ?>
