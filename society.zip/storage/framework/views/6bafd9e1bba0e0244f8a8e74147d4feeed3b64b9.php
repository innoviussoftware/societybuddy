<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Members
    <small><?php echo e($society->name); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.societies.index')); ?>">Societies</a></li>
    <li><a href="<?php echo e(route('admin.societies.edit', $society->id)); ?>"><?php echo e($society->name); ?></a></li>
    <li><a href="#">Members</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">

    <div class="col-xs-12">
      <div class="box">
        <?php if (\Entrust::hasRole(['admin','sub_admin'])) : ?>
        <ul class="nav nav-tabs">
         <li ><a href="<?php echo e(route('admin.societies.edit', $society->id)); ?>">Society Details</a></li>
         <li  ><a href="<?php echo e(route('admin.societies.buildings.add', $society->id)); ?>">Buildings</a></li>
         <li ><a href="<?php echo e(route('admin.societies.adminusers.index', $society->id)); ?>">Admin Users</a></li>
         <li class="active"><a href="<?php echo e(route('admin.societies.members.index', $society->id)); ?>">Members</a></li>
       </ul>
       <?php endif; // Entrust::hasRole ?>
        <div class="box-body">
          <a class="btn btn-primary" href="<?php echo e(route('admin.societies.members.add', $society->id)); ?>">+ Add Member</a>
          <br>
          <br>
          <table id="societies_datatable" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Building</th>
              <th>Flat</th>
              <th>Action</th>
            </tr>
            </thead>
          </table>
        </div>
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
$(document).ready(function(){

  var doctordatatable = $('#societies_datatable').DataTable({
      responsive: true,
      "processing": true,
      "ajax": "<?php echo e(route('admin.societies.arrayMembers', $society->id)); ?>",
      "language": {
          "emptyTable": "No any Member available"
      },
      "order": [[0, "desc"]],
  });
  doctordatatable.columns([0]).visible(false, false);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>