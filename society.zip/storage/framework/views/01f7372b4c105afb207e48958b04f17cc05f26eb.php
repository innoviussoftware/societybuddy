<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Add Guard
    <!-- <small>advanced tables</small> -->
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.guardes.index')); ?>">Guardes</a></li>
    <li><a href="#">Add</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">
    <div class="col-xs-6">
      <div class="box">
        <form action="<?php echo e(route('admin.guardes.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="box-header">
          <h3 class="box-title">Add Guard</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">
              <?php if (\Entrust::hasRole(['admin','sub_admin'])) : ?>
              <div class="form-group">
                <label>Society</label>
                  <select class="form-control" name="society" id="society" required>
                  <option disabled selected value="">Select Society</option>
                  <?php $__currentLoopData = $society; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php echo e(($s->id == old('society')) ? "selected" : ""); ?> ><?php echo e($s->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <?php endif; // Entrust::hasRole ?>
              <?php if (\Entrust::hasRole(['society_admin'])) : ?>
              <input type="hidden"  name="society" value="<?php echo e(auth()->user()->society_id); ?>">

              <?php endif; // Entrust::hasRole ?>

              <div class="form-group">
                <label for="exampleInputEmail1">Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter Guard Name" value="<?php echo e(old('name')); ?>" required>
              </div>
              <div class="form-group">
                <label>Login Pin</label>
                <input type="text" name="pin" class="form-control" placeholder="Enter Guard Login Pin" value="<?php echo rand(1000,9999); ?>" required readonly>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Contact No.</label>
                <input type="text" name="phone" class="form-control" placeholder="Enter Guard Contact No." value="<?php echo e(old('phone')); ?>" required>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Gender</label><br/>
                <input type="radio"  name="gender" value="male" checked> Male<br>
                <input type="radio"  name="gender" value="female"> Female<br>
              </div>
              <div class="form-group">
                <label>Profile Photo</label>
                <input type="file" class="form-control" name="profile_pic">
              </div>
            </div>
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a href="<?php echo e(route('admin.guardes.index')); ?>" class="btn btn-default">Cancel</a>
        </div>
      </form>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script>
$(document).ready(function (){
  $("body").on('change','#city',function (){
    var id  = $(this).val();
    getArea(id);
  });

  function getArea(id){
    $.ajax({
      url:"<?php echo e(env('APP_URL')); ?>/admin/areas/byCity/"+id,
      method:"get",
      success:function(e){

        var html = "<option>Select Area</option>";
        for(var i = 0; i < e.length; i++){
          html += "<option  value='"+e[i].id+"'>"+e[i].name+"</option>";
        }
        $("#area").html(html);
      }
    });
  }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>