<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e($society->name); ?>

    <small>Notice</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.societies.index')); ?>">Societies</a></li>
    <li><a href="<?php echo e(route('admin.societies.edit', $society->id)); ?>"><?php echo e($society->name); ?></a></li>
    <li><a href="<?php echo e(route('admin.societies.notices.index', $society->id)); ?>">Notices</a></li>
    <li><a href="#">Edit</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <form action="<?php echo e(route('admin.societies.notices.update', [$society->id, $notice->id])); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div class="box-header">
          <h3 class="box-title">Edit Notice</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
            <div class="form-group">
              <label>Building</label>
                <select class="form-control select2" name="building_id[]" id="building" required data-placeholder="Select a Building" multiple="multiple">                
                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                  $mysqlvalue= explode(",",$notice->building_id);?>
                  <option value="<?php echo e($b->id); ?>" <?php echo in_array($b->id,$mysqlvalue) ? "selected" : "" ?>><?php echo e($b->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
                <label >Title</label>
                <input type="text" name="title" class="form-control" placeholder="Enter Name" value="<?php echo e($notice->title); ?>" required>
              </div>
              <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" name="description" placeholder="Enter Description" required><?php echo e($notice->description); ?></textarea>
              </div>
              <div class="form-group">
                <label>View Till</label>
                <input type="text" name="view_till" class="form-control" placeholder="Enter Phone Number" value="<?php echo e($notice->view_till); ?>" required id="datepicker">
              </div>
            
            </div>
          </div>


        </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a href="<?php echo e(route('admin.societies.notices.index', $society->id)); ?>" class="btn btn-default">Cancel</a>
        </div>
      </form>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(env('APP_URL')); ?>/admin_assets/bower_components/select2/dist/js/select2.full.min.js"></script>
<script>
$(document).ready(function (){
  $(document).ready(function (){
    $('.select2').select2();

    $("body").on('change','#building',function (){
      var id  = $(this).val();
      getFlats(id);
    });

    $('#datepicker').datepicker({
      autoclose: true,
      format: 'dd/mm/yyyy',
       startDate:'+0d',
    })

  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>