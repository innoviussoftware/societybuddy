<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e($society->name); ?>

    <small>Committee</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.societies.index')); ?>">Societies</a></li>
    <li><a href="<?php echo e(route('admin.societies.edit', $society->id)); ?>"><?php echo e($society->name); ?></a></li>
    <li><a href="<?php echo e(route('admin.societies.commitees.index', $society->id)); ?>">Committees</a></li>
    <li><a href="#">Edit</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <form action="<?php echo e(route('admin.societies.commitees.update', $society->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="box">

        <div class="box-header">
          <h3 class="box-title">Edit Society Committee</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Chairman</label>
                <select class="form-control select2" name="chairman"  data-placeholder="Select a Chairman">
                  <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo ($role->id == $society_committee['chairman']) ? "selected" : "" ?>><?php echo e($role->name." - ".(($role->member->flat) ? $role->member->flat->name  : "")); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label>Secretory</label>
                <select class="form-control select2" name="secretory"  data-placeholder="Select a Secretory">
                  <option value="" >Selecte Secretory</option>
                  <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e(($role->id == $society_committee['secretory']) ? "selected" : ""); ?>><?php echo e($role->name." - ".(($role->member->flat) ? $role->member->flat->name  : "")); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label>Jt. Secretory</label>
                <select class="form-control select2" name="jt_secretory"  data-placeholder="Select a Jt. Chairman">
                  <option value="" >Selecte Jt. Secretory</option>
                  <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>"  <?php echo e(($role->id == $society_committee['jt_secretory']) ? "selected" : ""); ?>><?php echo e($role->name." - ".(($role->member->flat) ? $role->member->flat->name  : "")); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label>Treasurer</label>
                <select class="form-control select2" name="treasurer"  data-placeholder="Select a Treasurer">
                  <option value="" >Selecte Treasurer</option>
                  <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e(($role->id == $society_committee['treasurer']) ? "selected" : ""); ?> ><?php echo e($role->name." - ".(($role->member->flat) ? $role->member->flat->name  : "")); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label>Committees</label>
                <select class="form-control select2" name="commitees[]" multiple="multiple" data-placeholder="Select a Commitee" >
                  <option value="" >Selecte Committees</option>
                  <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo in_array($role->id, $society_committee['commitees']) ? "selected" : "" ?>><?php echo e($role->name ." - ".(($role->member->flat) ? $role->member->flat->name  : "")); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a href="<?php echo e(route('admin.societies.commitees.index', $society->id)); ?>" class="btn btn-default">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(env('APP_URL')); ?>/admin_assets/bower_components/select2/dist/js/select2.full.min.js"></script>
<script>
  $(document).ready(function (){
    $('.select2').select2();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>