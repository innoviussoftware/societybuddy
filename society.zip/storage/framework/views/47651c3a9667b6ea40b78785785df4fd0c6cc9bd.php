<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    
    <small>Circular</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.societies.index')); ?>">Societies</a></li>
    <li><a href="<?php echo e(route('admin.societies.edit', $society->id)); ?>"><?php echo e($society->name); ?></a></li>
    <li><a href="<?php echo e(route('admin.societies.circulars.index', $society->id)); ?>">Circular</a></li>
    <li><a href="#">Add</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <form action="<?php echo e(route('admin.societies.circulars.store', $society->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="box-header">
          <h3 class="box-title">Add Circular</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Building</label>
                  <select class="form-control select2" name="building_id[]" id="building" required multiple="multiple" data-placeholder="Select Building">
                  
                  <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b->id); ?>" <?php echo e(($b->id == old('building_id')) ? "selected" : ""); ?> ><?php echo e($b->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              
            
              <div class="form-group">
                <label >Title</label>
                <input type="text" name="title" class="form-control" placeholder="Enter Title" value="<?php echo e(old('title')); ?>" required>
              </div>
              <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" name="description" placeholder="Enter Description" required=""><?php echo e(old('description')); ?></textarea>
               
              </div>

              <div class="form-group">
                <label>Pdf</label>
                <input type="file" class="form-control" name="pdf">
              </div>
             
            </div>
          </div>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a href="<?php echo e(route('admin.societies.circulars.index', $society->id)); ?>" class="btn btn-default">Cancel</a>
        </div>
      </form>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(env('APP_URL')); ?>/admin_assets/bower_components/select2/dist/js/select2.full.min.js"></script>

<script>
$(document).ready(function (){
  $('.select2').select2()

  $("body").on('change','#building',function (){
    var id  = $(this).val();
    getFlats(id);
  });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>