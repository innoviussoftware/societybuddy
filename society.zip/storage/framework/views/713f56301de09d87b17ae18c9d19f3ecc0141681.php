<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e($society->name); ?>

    <small>Admin users</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.societies.index')); ?>">Societies</a></li>
    <li><a href="<?php echo e(route('admin.societies.edit', $society->id)); ?>"><?php echo e($society->name); ?></a></li>
    <li><a href="<?php echo e(route('admin.societies.adminusers.index', $society->id)); ?>">Admin Users</a></li>
    <li><a href="#">Add</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <form action="<?php echo e(route('admin.societies.adminusers.store', $society->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="box-header">
          <h3 class="box-title">Add Admin Users</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label >Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter Name" value="<?php echo e(old('name')); ?>" required>
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter Email" value="<?php echo e(old('email')); ?>" required>
              </div>
              <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" class="form-control" placeholder="Enter Phone Number" value="<?php echo e(old('phone')); ?>" required>
              </div>
              <div class="form-group">
                <label >Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter Password"  required>
              </div>
              <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password"  required>
              </div>

              <div class="form-group">
                <label>Image</label>
                <input type="file" class="form-control" name="image">
              </div>
            </div>
          </div>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
          <a href="<?php echo e(route('admin.societies.adminusers.index', $society->id)); ?>" class="btn btn-default">Cancel</a>
        </div>
      </form>
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script>
$(document).ready(function (){
  $("body").on('change','#city',function (){
    var id  = $(this).val();
    getArea(id);
  });

  function getArea(id){
    $.ajax({
      url:"<?php echo e(env('APP_URL')); ?>/admin/areas/byCity/"+id,
      method:"get",
      success:function(e){

        var html = "<option>Select Area</option>";
        for(var i = 0; i < e.length; i++){
          html += "<option  value='"+e[i].id+"'>"+e[i].name+"</option>";
        }
        $("#area").html(html);
      }
    });
  }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>