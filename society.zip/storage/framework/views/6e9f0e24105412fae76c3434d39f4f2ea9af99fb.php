<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Edit Building
    <small><?php echo e($society->name); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="<?php echo e(route('admin.societies.index')); ?>">Societies</a></li>
    <li><a href="<?php echo e(route('admin.societies.edit', $society->id)); ?>"><?php echo e($society->name); ?></a></li>
    <li><a href="<?php echo e(route('admin.societies.buildings.add', $society->id)); ?>">Buildings</a></li>
    <li><a href="#">Add</a></li>
  </ol>
</section>

<section class="content">
  <div class="row">

    <div class="col-xs-12">
      <div class="box">


        <form action="<?php echo e(route('admin.societies.buildings.update',[$society->id, $building->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PATCH"); ?>
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Building Name</label>
                <input type="text" class="form-control" name="name" required value="<?php echo e($building->name); ?>">
              </div>
              <label>Add Flats <button class="btn btn-default btn-xs add_flat" type="button">+</button></label>

                <div class="row" id="flats">
                  <?php $__currentLoopData = $building->flats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-4" >
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Flat No." name="flats[]" value="<?php echo e($f->name); ?>">
                      <span class="input-group-btn">
                        <button class="btn btn-danger delete_flat" type="button">-</button>
                      </span>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
      </div>
    </div>


</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
$(document).ready(function(){
  $("body").on("click",".add_flat",function(){
    var html = '<div class="col-md-4"> <div class="input-group"><input type="text" name="flats[]" class="form-control" placeholder="Flat no."><span class="input-group-btn"><button class="btn btn-danger delete_flat" type="button">-</button></span></div></div>';
    $("#flats").append(html);
  });
  $("body").on("click","#flats button.delete_flat",function(){
    $(this).closest(".col-md-4").remove();
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>