<header class="main-header">
  <!-- Logo -->
  <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <span class="logo-mini"><b>S</b></span>
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><b><?php echo e(env('APP_NAME')); ?></b></span>
  </a>
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top">
    <?php if (\Entrust::hasRole(['admin','sub_admin'])) : ?>
    <!-- Sidebar toggle button-->
    <a href="<?php echo e(env('APP_URL')); ?>/admin_assets/#" class="sidebar-toggle" data-toggle="push-menu" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a>
    <?php endif; // Entrust::hasRole ?>
    <?php if (\Entrust::hasRole(['society_admin'])) : ?>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
      <li class="dropdown">
         <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-users" aria-hidden="true"></i> Manage Society
         <span class="caret"></span></a>
         <ul class="dropdown-menu">
           <li><a href="<?php echo e(route('admin.societies.edit',auth()->user()->society_id)); ?>">Manage Society Details</a></li>
           <li><a href="<?php echo e(route('admin.societies.buildings.add',auth()->user()->society_id)); ?>">Manage Building</a></li>
           <li><a href="<?php echo e(route('admin.societies.adminusers.index',auth()->user()->society_id)); ?>">Manage Admins</a></li>
           <li><a href="<?php echo e(route('admin.guardes.index')); ?>">Manage Guards</a></li>
           <li><a href="<?php echo e(route('admin.societies.commitees.index',auth()->user()->society_id)); ?>">Manage Commitee</a></li>
           <li><a href="<?php echo e(route('admin.societies.notices.index',auth()->user()->society_id)); ?>">Manage Notices</a></li>
           <li><a href="<?php echo e(route('admin.societies.events.index',auth()->user()->society_id)); ?>">Manage Events</a></li>
           <li><a href="<?php echo e(route('admin.societies.circulars.index',auth()->user()->society_id)); ?>">Manage Circulars</a></li>
         </ul>
      </li>
      <li><a href="<?php echo e(route('admin.societies.members.index',auth()->user()->society_id)); ?>"><i class="fa fa-building" aria-hidden="true"></i> Manage Residents</a></li>
      <li><a href="#"><i class="fa fa-cogs" aria-hidden="true"></i> Manage Service Providers</a></li>
      <li><a href="#"><i class="fa fa-file-text" aria-hidden="true"></i> Reports</a></li>
      <li><a href="#"><i class="fa fa-info-circle" aria-hidden="true"></i> Help desk</a></li>

    </ul>
    <?php endif; // Entrust::hasRole ?>

    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <li class="dropdown user user-menu">
          <a href="<?php echo e(env('APP_URL')); ?>/admin_assets/#" class="dropdown-toggle" data-toggle="dropdown">
            <img src="<?php echo e(env('APP_URL')); ?>/admin_assets/dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
            <span class="hidden-xs"><?php echo e(auth()->user()->name); ?></span>
          </a>
          <ul class="dropdown-menu">
            <!-- User image -->
            <li class="user-header">
              <img src="<?php echo e(env('APP_URL')); ?>/admin_assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

              <p>
                <?php echo e(auth()->user()->name); ?>

                <?php if(auth()->user()->created_at): ?>
                  <small>Member since <?php echo e(date("M j, Y", strtotime(auth()->user()->created_at))); ?></small>
                <?php endif; ?>
              </p>
            </li>
            <!-- Menu Body -->
            <!-- <li class="user-body">
              <div class="row">
                <div class="col-xs-4 text-center">
                  <a href="#">Followers</a>
                </div>
                <div class="col-xs-4 text-center">
                  <a href="#">Sales</a>
                </div>
                <div class="col-xs-4 text-center">
                  <a href="#">Friends</a>
                </div>
              </div>
            </li> -->
            <!-- Menu Footer-->
            <li class="user-footer">
              <div class="pull-left">
                <a href="#" class="btn btn-default btn-flat">Profile</a>
              </div>
              <div class="pull-right">
                <a class="btn btn-default btn-flat" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
              </div>
            </li>
          </ul>
        </li>
        <!-- Control Sidebar Toggle Button -->
      </ul>
    </div>
  </nav>
</header>
