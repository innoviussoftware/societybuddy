<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Role;
use App\City;
use App\User;
use App\Area;
use App\Society;
use App\Flat;
use App\Building;
use App\Member;

class SocietyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return view('admin.societies.index');
    }

    public function indexAdminUsers($id){
        $society = Society::find($id);
        if($society){
          return view('admin.societies.adminusers.index',["society" => $society]);
        }else{
          return view('admin.errors.404');
        }
    }
    public function indexMembers($id){
        $society = Society::find($id);
        if($society){
          return view('admin.societies.members.index',["society" => $society]);
        }else{
          return view('admin.errors.404');
        }
    }
    public function indexCommitees($id){
        $society = Society::find($id);

        $chairman = User::whereHas('roles', function($q){
            $q->where('name', 'chairman');
        })->where("society_id",$society->id)->first();

        $secretory = User::whereHas('roles', function($q){
            $q->where('name', 'secretory');
        })->where("society_id",$society->id)->first();

        $jt_secretory = User::whereHas('roles', function($q){
          $q->where('name', 'jt_secretory');
        })->where("society_id",$society->id)->first();

        $treasurer = User::whereHas('roles', function($q){
            $q->where('name', 'treasurer');
        })->where("society_id",$society->id)->first();

        if($society){
          return view('admin.societies.commitees.index',["society" => $society,'chairman'=>$chairman,'secretory'=>$secretory,'jt_secretory'=>$jt_secretory,'treasurer'=>$treasurer]);
        }else{
          return view('admin.errors.404');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add(){
        $cities = City::all();
        if(old('city')){
          $areas = Area::where('city_id', old('city'))->get();
        }else{
          $areas = [];
        }
        return view('admin.societies.add',['cities' => $cities, 'areas' => $areas]);
    }

    public function addBuildings($id){
        $society = Society::find($id);
        if($society){
          return view('admin.societies.buildings.add',["society" => $society]);
        }else{
          return view('admin.errors.404');
        }
    }
    public function addAdminUsers($id){
        $society = Society::find($id);
        if($society){
          return view('admin.societies.adminusers.add',["society" => $society]);
        }else{
          return view('admin.errors.404');
        }
    }
    public function addMembers($id){
        $society = Society::find($id);
        $roles = Role::memberRoles();
        if($society){
          $buildings = Building::where('society_id',$id)->get();
          return view('admin.societies.members.add',["society" => $society, 'buildings' => $buildings, 'roles' => $roles]);
        }else{
          return view('admin.errors.404');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
      $this->validate($request, [
          'name' => 'required',
          'area' => 'required',
          'address' => 'required',
          'email' => 'required|email|unique:societies',
          'contact' => 'required|numeric|unique:societies,contact',
          'logo' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
      ]);

        $city = new Society;
        $city->name = request('name');
        $city->area_id = request('area');
        $city->address = request('address');
        $city->email = request('email');
        $city->contact = request('contact');

        if ($request->file('document')) {
            $image = $request->document;
            $path = $image->store('document');
        }
        $city->document = isset($path) ? $path : "";
        if ($request->file('logo')) {
            $imageLogo = $request->logo;
            $logo = $imageLogo->store('society_logo');
        }
        $city->logo = isset($logo) ? $logo : "";;
        $city->save();
        return redirect()->route('admin.societies.buildings.add',$city->id)->with("success","Society added successfully.");
    }

    public function storeBuildings(Request $request, $society_id){
        $this->validate($request, [
            'name' => 'required',
            'flats' => 'required'
        ]);
        $city = new Building();
        $city->name = request('name');
        $city->society_id = $society_id;
        $city->save();
        $flats = request('flats');
        foreach ($flats as  $f) {
          Flat::create(array('name' => $f, "building_id" => $city->id));
        }
        return redirect()->route('admin.societies.buildings.add',$society_id)->with("success","Society Building added successfully.");
    }
    public function storeAdminUsers(Request $request, $society_id)    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'phone' => 'required|numeric',
            'password' => 'required|confirmed|min:6'
        ]);
        $city = new User();
        $city->name = request('name');
        $city->society_id = $society_id;
        $city->name = request('name');
        $city->email = request('email');
        $city->phone = request('phone');
        $city->password = Hash::make(request('password'));
        if ($request->file('image')) {
            $image = $request->image;
            $path = $image->store('user');
        }
        $city->image = isset($path) ? $path : "";
        $city->save();
        // role attach society admin which has 8 id
        $city->attachRole(8); // parameter can be an Role object, array, or id
        return redirect()->route('admin.societies.adminusers.index',$society_id)->with("success","Society Admin Users added successfully.");
    }

    public function storeMembers(Request $request, $society_id)    {
        $this->validate($request, [
            'building_id' => 'required',
            'flat_id' => 'required',
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'phone' => 'required|numeric||unique:users,phone',
            'roles' => 'required',
        ]);
        $city = new User();
        $city->name = request('name');
        $city->society_id = $society_id;
        $city->email = request('email');
        $city->phone = request('phone');
        $city->password = Hash::make('123456');
        if ($request->file('image')) {
            $image = $request->image;
            $path = $image->store('user');
        }
        $city->image = isset($path) ? $path : "";
        $city->save();
        // role attach society admin which has 8 id
        $roles = request('roles');
        foreach ($roles as $r) {
          $city->attachRole($r);
        }

        $member = new Member;
        $member->user_id = $city->id;
        $member->society_id = $society_id;
        $member->building_id = request('building_id');
        $member->flat_id = request('flat_id');
        $member->gender = request('gender');
        $member->save();
        return redirect()->route('admin.societies.members.index',$society_id)->with("success","Society Members added successfully.");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    public function checkForSocietyAdmin($society_id){
      //If user has role society_admin then make sure he/she can only access their society
      if(auth()->user()->hasRole('society_admin')){
        if(auth()->user()->society_id != $society_id){
          abort(403, 'Unauthorized action.');
        }
      }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $this->checkForSocietyAdmin($id);
        $society = Society::find($id);
        if($society){
          $cities = City::all();
          $areas = Area::where('city_id',$society->area->city_id)->get();
          // dd($areas);
          return view('admin.societies.edit',["society" => $society,'cities' => $cities, 'areas' => $areas]);
        }else{
          return view('admin.errors.404');
        }
    }
    public function editBuildings($society_id,$building_id)
    {
        $this->checkForSocietyAdmin($society_id);

        $s = Society::find($society_id);
        $b = Building::find($building_id);
        if($b && $s){
          return view('admin.societies.buildings.edit',["society" => $s,"building" => $b]);
        }else{
          return view('admin.errors.404');
        }
    }
    public function editAdminUsers($society_id,$user_id){
      $this->checkForSocietyAdmin($society_id);

        $s = Society::find($society_id);
        $b = User::find($user_id);
        if($b && $s){
          return view('admin.societies.adminusers.edit',["society" => $s,"user" => $b]);
        }else{
          return view('admin.errors.404');
        }
    }

    public function editMembers($society_id,$member_id){
      $this->checkForSocietyAdmin($society_id);

        $s = Society::find($society_id);
        $b = Member::find($member_id);
        if($b && $s){
          $buildings = Building::where("society_id",$society_id)->get();
          $flats = Flat::where("building_id",$b->building_id)->get();
          $roles = Role::memberRoles();
          $userroles = $b->user->roles->pluck('id')->toArray();
          return view('admin.societies.members.edit',["society" => $s,"member" => $b, 'buildings'=> $buildings, 'roles' => $roles, 'userroles' => $userroles, 'flats' => $flats]);
        }else{
          return view('admin.errors.404');
        }
    }
    public function editCommitees($society_id){
      $this->checkForSocietyAdmin($society_id);
      $s = Society::find($society_id);
      if($s){

        $chairman = User::whereHas('roles', function($q){
            $q->where('name', 'chairman');
        })->where("society_id",$society_id)->first();


        $secretory = User::whereHas('roles', function($q){
            $q->where('name', 'secretory');
        })->where("society_id",$society_id)->first();

        $jt_secretory = User::whereHas('roles', function($q){
          $q->where('name', 'jt_secretory');
        })->where("society_id",$society_id)->first();

        $treasurer = User::whereHas('roles', function($q){
            $q->where('name', 'treasurer');
        })->where("society_id",$society_id)->first();

        $commitees = User::whereHas('roles', function($q){
          $q->where('name', 'committee_member');
        })->where("society_id",$society_id)->pluck('id')->toArray();

        $society_committee = [
          'chairman' => $chairman ? $chairman->id : 0,
          'secretory' => $secretory ? $secretory->id : 0,
          'jt_secretory' => $jt_secretory ? $jt_secretory->id : 0,
          'treasurer' => $treasurer ? $treasurer->id : 0,
          'commitees' => $commitees ? $commitees : []
        ];
        // dd($society_committee['treasurer']);

        $members = User::with(['member'])->whereHas('roles', function($q){
          $q->where('name', 'chairman');
          $q->orWhere('name', 'committee_member');
          $q->orWhere('name', 'secretory');
          $q->orWhere('name', 'jt_secretory');
          $q->orWhere('name', 'treasurer');
          $q->orWhere('name', 'member');
        })->where("society_id",$society_id)->get();

        return view('admin.societies.commitees.edit', ['society' => $s, 'members' => $members, 'society_committee' => $society_committee]);
      }else{
        return view('admin.errors.404');
      }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id){
        //
        $this->validate($request, [
            'name' => 'required',
            'area' => 'required',
            'address' => 'required',
            'email' => 'required',
            'contact' => 'required',
        ]);

        $s = Society::find($id);
        if($s){
          $s->name = request('name');
          $s->area_id = request('area');
          $s->address = request('address');
          $s->email = request('email');
          $s->contact = request('contact');

          if ($request->file('document')) {
              $image = $request->document;
              $path = $image->store('document');
              $s->document = isset($path) ? $path : "";
          }
          if ($request->file('logo')) {
              $imageLogo = $request->logo;
              $logo = $imageLogo->store('society_logo');
              $s->logo = isset($logo) ? $logo : "";
          }
          $s->save();
        }
        if(auth()->user()->hasRole('society_admin')){
          return redirect()->route('admin.societies.edit',$id)->with('success','Society updated successfully.');
        }else{
          return redirect()->route('admin.societies.index')->with('success','Society updated successfully.');
        }
    }
    public function updateBuildings(Request $request, $society_id, $building_id){
        $this->validate($request, [
            'name' => 'required',
            'flats' => 'required',
        ]);
        $area = Building::find($building_id);
        if($area){
          $area->name = request('name');
          $area->save();
          $flats = request('flats');
          foreach ($flats as  $f) {
            Flat::firstOrCreate(array('name' => $f, "building_id" => $building_id));
          }
        }
        return redirect()->route('admin.societies.buildings.add', $society_id)->with('success','Building updated successfully.');
    }
    public function updateAdminUsers(Request $request, $society_id, $user_id){
      $this->validate($request, [
          'name' => 'required',
          // 'email' => 'required|email|unique:users',
          // 'password' => 'required'
      ]);
        $user = User::find($user_id);
        if($user){
          $user->name = request('name');
          $user->phone = request('phone');

          // if (request('password')) {
          //   $user->password = Hash::make(request('password'));
          // }
          if ($request->file('image')) {
              $image = $request->image;
              $path = $image->store('user');
          }
          $user->image = isset($path) ? $path : "";
          $user->save();
        }
        return redirect()->route('admin.societies.adminusers.index', $society_id)->with('success','Admin User updated successfully.');
    }
    public function updateMembers(Request $request, $society_id, $member_id){
      $this->validate($request, [
          'building_id' => 'required',
          'flat_id' => 'required',
          'name' => 'required',
          'roles' => 'required',
          'gender' => 'required',
      ]);
        $member = Member::find($member_id);
      if($member){
          $member->building_id = request('building_id');
          $member->flat_id = request('flat_id');
          $member->gender = request('gender');
          $member->save();
          $user = User::find($member->user_id);
          $user->name = request('name');
          if ($request->file('image')) {
              $image = $request->image;
              $path = $image->store('user');
              $user->image = isset($path) ? $path : "";
          }
          $user->save();
          $user->roles()->sync(request('roles')); // ex. ['9','5']
        }
        return redirect()->route('admin.societies.members.index', $society_id)->with('success','Member updated successfully.');
    }
    public function updateCommitees(Request $request, $society_id){

      $society = Society::find($society_id);
      if($society){
          $all_commitees = User::whereHas('roles', function($q){
              $q->where('name', 'chairman');
              $q->orWhere('name', 'committee_member');
              $q->orWhere('name', 'secretory');
              $q->orWhere('name', 'jt_secretory');
              $q->orWhere('name', 'treasurer');
          })->where("society_id",$society_id)->get();

          foreach ($all_commitees as $c) {
            $c->roles()->sync([9]); //Make default member. 9 = member
          }

          if(request('chairman')){
            $c = User::find(request('chairman'));
            if($c){
              $c->attachRole(3); //3 = Chairman
            }
          }

          if(request('secretory')){
            $s = User::find(request('secretory'));
            if($s){
              $s->attachRole(5); //5 = secretory
            }
          }

          if(request('jt_secretory')){
            $js = User::find(request('jt_secretory'));
            if($js){
              $js->attachRole(6); //6 = Jt. secretory
            }
          }
          if(request('treasurer')){
            $t = User::find(request('treasurer'));
            if($t){
              $t->attachRole(7); //7 = Treasurer
            }
          }
          if(request('commitees')){
            $cts = User::whereIn('id',request('commitees'))->get();
            foreach ($cts as $u) {
              $u->attachRole(4); //7 = Committee Member
            }
          }

        }
        return redirect()->route('admin.societies.commitees.index', $society_id)->with('success','Member updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id){
        $city = Society::find($id);
        if($city){
          $city->delete();
        }
        return redirect()->route('admin.societies.index')->with('success','Area deleted successfully.');

    }
    public function deleteBuildings($society_id,$building_id){
        $city = Building::find($building_id);
        if($city){
          $city->delete();
        }
        return redirect()->route('admin.societies.buildings.add',$society_id)->with('success','Building deleted successfully.');

    }
    public function deleteAdminUsers($society_id,$user_id){
        $city = User::find($user_id);
        if($city){
          $city->delete();
        }
        return redirect()->route('admin.societies.adminusers.index',$society_id)->with('success','Admin User deleted successfully.');

    }
    public function deleteMembers($society_id,$member_id){
        $member = Member::find($member_id);
        if($member){
          $city = User::find($member->user_id);
          $city->delete();
          $member->delete();
        }
        return redirect()->route('admin.societies.adminusers.index',$society_id)->with('success','Admin User deleted successfully.');

    }


        public function Array(Request $request){
            $response = [];
            $sosieties = Society::all();
            foreach ($sosieties as $s) {
                $sub = [];
                $id = $s->id;
                $sub[] = $id;
                $sub[] = $s->name;
                $sub[] = $s->email;
                $sub[] = $s->contact;
                $sub[] = $s->area->city->name;
                $sub[] = $s->area->name;
                $sub[] = $s->address;
                $sub[] = $s->created_at->toDateTimeString();
                // $sub[] = "<img src='$s->document' width='100'/>";
                $delete_url = route('admin.societies.delete', [$id]);
                $action = '<div class="btn-part"><a class="edit" href="' . route('admin.societies.edit', $id) . '"><i class="fa fa-pencil-square-o"></i></a>' . ' ';
                $action .= '<a class="delete" onclick="return confirm(`Are you sure you want to delete this record?`)"  href="'.route('admin.societies.delete',$id).'"><i class="fa fa-trash"></i>&nbsp;</a></div>';
                $sub[] = $action;
                $response[] = $sub;
              }
            $userjson = json_encode(["data" => $response]);
            echo $userjson;
        }
        public function ArrayBuildings(Request $request, $society_id){
            $response = [];
            $sosieties = Building::where("society_id",$society_id)->get();
            foreach ($sosieties as $s) {
                $sub = [];
                $id = $s->id;
                $sub[] = $id;
                $sub[] = $s->name;
                // $sub[] = "<img src='$s->document' width='100'/>";
                $delete_url = route('admin.societies.buildings.delete', ["society_id" => $society_id, "building_id" => $id]);
                $action = '<div class="btn-part"><a class="edit" href="'.route('admin.societies.buildings.edit', ["society_id" => $society_id, "building_id" => $id]).'"><i class="fa fa-pencil-square-o"></i></a>' . ' ';
                $action .= '<a class="delete" onclick="return confirm(`Are you sure you want to delete this record?`)"  href="'.$delete_url.'"><i class="fa fa-trash"></i>&nbsp;</a></div>';
                $sub[] = $action;
                $response[] = $sub;
              }
            $userjson = json_encode(["data" => $response]);
            echo $userjson;
        }
        public function ArrayAdminUsers(Request $request, $society_id){
            $response = [];
            // $sosieties = User::withRole('society_admin')->where("society_id",$society_id)->get();

            $sosieties = User::whereHas('roles', function($q){
                $q->where('name', 'society_admin');
            })->where("society_id",$society_id)->get();
            foreach ($sosieties as $s) {
                $sub = [];
                $id = $s->id;
                $sub[] = $id;
                $sub[] = $s->name;
                $sub[] = $s->email;
                // $sub[] = "<img src='$s->document' width='100'/>";
                $delete_url = route('admin.societies.adminusers.delete', ["society_id" => $society_id, "user_id" => $id]);
                $action = '<div class="btn-part"><a class="edit" href="'.route('admin.societies.adminusers.edit', ["society_id" => $society_id, "user_id" => $id]).'"><i class="fa fa-pencil-square-o"></i></a>' . ' ';
                $action .= '<a class="delete" onclick="return confirm(`Are you sure you want to delete this record?`)"  href="'.$delete_url.'"><i class="fa fa-trash"></i>&nbsp;</a></div>';
                $sub[] = $action;
                $response[] = $sub;
              }
            $userjson = json_encode(["data" => $response]);
            echo $userjson;
        }
        public function ArrayMembers(Request $request, $society_id){
            $response = [];
            $sosieties = Member::where("society_id",$society_id)->get();
            foreach ($sosieties as $s) {
                $sub = [];
                $id = $s->id;
                $sub[] = $id;
                $sub[] = $s->user->name;
                $sub[] = $s->user->email;
                $sub[] = $s->building->name;
                $sub[] = $s->flat->name;
                $delete_url = route('admin.societies.members.delete', ["society_id" => $society_id, "member_id" => $id]);
                $action = '<div class="btn-part"><a class="edit" href="'.route('admin.societies.members.edit', ["society_id" => $society_id, "member_id" => $id]).'"><i class="fa fa-pencil-square-o"></i></a>' . ' ';
                $action .= '<a class="delete" onclick="return confirm(`Are you sure you want to delete this record?`)"  href="'.$delete_url.'"><i class="fa fa-trash"></i>&nbsp;</a></div>';
                $sub[] = $action;
                $response[] = $sub;
              }
            $userjson = json_encode(["data" => $response]);
            echo $userjson;
        }
        public function ArrayCommitees(Request $request, $society_id){
            $response = [];
            $sosieties = User::whereHas('roles', function($q){
                $q->where('name', 'committee_member');
                // $q->orWhere('name', 'chairman');
                // $q->orWhere('name', 'secretory');
                // $q->orWhere('name', 'jt_secretory');
                $q->orWhere('name', 'treasurer');
            })->where("society_id",$society_id)->get();

            foreach ($sosieties as $s) {
                $sub = [];
                $id = $s->id;
                $sub[] = $id;
                $sub[] = $s->name;
                $sub[] = $s->phone;
                $sub[] = $s->email;
                // $sub[] = $s->member->building->name;
                $sub[] = isset($s->member->flat->name)?$s->member->building->name .'-'.$s->member->flat->name:'';
                // $sub[] = $s->roles->pluck('display_name')->toArray();
                $delete_url = route('admin.societies.members.delete', ["society_id" => $society_id, "member_id" => $id]);
                $action = '<div class="btn-part"><a class="edit" href="'.route('admin.societies.members.edit', ["society_id" => $society_id, "member_id" => $id]).'"><i class="fa fa-pencil-square-o"></i></a>' . ' ';


                $action .= '<a class="delete" onclick="return confirm(`Are you sure you want to delete this record?`)"  href="'.$delete_url.'"><i class="fa fa-trash"></i>&nbsp;</a></div>';
                // $sub[] = $action;
                $response[] = $sub;
              }
            $userjson = json_encode(["data" => $response]);
            echo $userjson;
        }

        public function flatsByBuilding($building_id){
          $f = Flat::select('id','name')->where('building_id',$building_id)->get();
          return response()->json($f);
        }

}
