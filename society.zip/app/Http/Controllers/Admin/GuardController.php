<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\City;
use App\Area;
use App\Society;
use App\Building;
use App\Guard;
use Illuminate\Support\Facades\Storage;
class GuardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){

        return view('admin.guard.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add()
    {
        $society = Society::all();
        return view('admin.guard.add',['society' => $society]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    	// dd($request->all());
      $this->validate($request, [
          'name' => 'required',
          'pin' => 'required',
          'phone' => 'required | numeric',
          'gender' => 'required',
          'society' => 'required'
      ]);

        $user = new Guard;
        $user->name = request('name');
        $user->login_pin = request('pin');
        $user->phone = request('phone');
        $user->gender = request('gender');
        $user->society_id = request('society');

        if ($request->file('profile_pic')) {
            $image = $request->profile_pic;
            $path = $image->store('guards');
        }
        $user->profile_pic = isset($path) ? $path : "";
        $user->save();
        return redirect()->route('admin.guardes.index')->with("success","Guard added successfully.");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $guard = Guard::find($id);
        if($guard){
          $this->checkForSocietyAdmin($guard->society_id);
          $society = Society::all();
          return view('admin.guard.edit',["society" => $society,'guard' => $guard]);
    	}else{
          return view('admin.errors.404');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'name' => 'required',
          	'pin' => 'required',
          	'phone' => 'required | numeric',
          	'gender' => 'required',
          	'society' => 'required'
        ]);
        $guard = Guard::find($id);
        if($guard){
          if(!auth()->user()->hasRole('society_admin')){
            $guard->society_id = request('society');
          }
          $guard->name = request('name');
          $guard->login_pin = request('pin');
          $guard->phone = request('phone');
          $guard->gender = request('gender');
          if ($request->file('profile_pic')) {
            $image = $request->profile_pic;
            $path = $image->store('guards');
          }
          $guard->profile_pic = isset($path) ? $path : request('profile_hidden');
          $guard->save();
        }
        return redirect()->route('admin.guardes.index')->with('success','Guard updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $guard = Guard::find($id);
        if($guard){
          $guard->delete();
        }
        return redirect()->route('admin.guardes.index')->with('success','Guard deleted successfully.');

    }

    public function Array(Request $request)
        {
            $response = [];
            if(auth()->user()->hasRole('society_admin')){
              $guardes = Guard::where('society_id',auth()->user()->society_id)->get();
            }else{
              $guardes = Guard::all();
            }
            // echo url('storage/images/');
            foreach ($guardes as $g) {
                $sub = [];
                $id = $g->id;
                if($g->profile_pic)
                { 
                  $img = env('APP_URL_STORAGE').$g->profile_pic;
                } else {
                  $img = asset('no-image.png');
                }
                $sub[] = $id;
                $sub[] = "<a class='example-image-link' href='".$img."' data-lightbox='example-1'><img width='50' class='example-image' src='".$img."' alt='image-1' /></a>";
                $sub[] = $g->name;
                if(!auth()->user()->hasRole('society_admin')){
                $sub[] = isset($g->guards->name)?$g->guards->name:'';
                }
                $sub[] = $g->phone;
                $sub[] = $g->login_pin;
                $sub[] = $g->gender;
                $sub[] = $g->created_at->toDateTimeString();
                $delete_url = route('admin.guardes.delete', [$id]);
                $action = '<div class="btn-part"><a class="edit" href="' . route('admin.guardes.edit', $id) . '"><i class="fa fa-pencil-square-o"></i></a>' . ' ';
                $action .= '<a class="delete" onclick="return confirm(`Are you sure you want to delete this record?`)"  href="'.route('admin.guardes.delete',$id).'"><i class="fa fa-trash"></i>&nbsp;</a></div>';
                $sub[] = $action;
                $response[] = $sub;
              }
            $userjson = json_encode(["data" => $response]);
            echo $userjson;
        }

        public function checkForSocietyAdmin($society_id)
        {
          //If user has role society_admin then make sure he/she can only access their society
          if(auth()->user()->hasRole('society_admin')){
            if(auth()->user()->society_id != $society_id){
              abort(403, 'Unauthorized action.');
            }
          }
        }

}
