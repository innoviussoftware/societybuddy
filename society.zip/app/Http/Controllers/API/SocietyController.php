<?php
namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;
use App\Role;
use App\City;
use App\User;
use App\Area;
use App\Society;
use App\Flat;
use App\Building;
use App\Member;

class SocietyController extends Controller
{
    //
    public function getcity(Request $request)
    {
    	$city = request('city');
    	if($city){
    		$cities = City::find($city,['id','name']);
    		return response()->json(['data' => $cities,'status'=>1,'message' => "Successfully get city."] , 200);
    	}else{
    		$cities = City::all(['id','name']);
    		return response()->json(['data' => $cities,'status'=>1,'message' => "Successfully get city."] , 200);
    	}
    	
    }

    public function getarea(Request $request)
    {
    	$city = request('city_id');
    	if($city){
    		$area = Area::select('id','city_id','name')->where('city_id', $city)->get();
    		return response()->json(['data' => $area,'status'=>1,'message' => "Successfully get area."] , 200);
    	}else{
    		$area = Area::all(['id','city_id','name']);
    		return response()->json(['data' => $area,'status'=>1,'message' => "Successfully get area."] , 200);
    	}
    }

    public function getsociety(Request $request)
    {
    	$area = request('area_id');
    	if($area){
    		$society = Society::select('id','address','area_id','name')->where('area_id', $area)->get();
    		return response()->json(['data' => $society,'status'=>1,'message' => "Successfully get society."] , 200);
    	}else{
    		$society = Society::all(['id','address','area_id','name']);
    		return response()->json(['data' => $society,'status'=>1,'message' => "Successfully get society."] , 200);
    	}
    }

    public function getbuilding(Request $request)
    {
    	$society = request('society_id');
    	if($society){
    		$building = Building::select('id','society_id','name')->where('society_id', $society)->get();
    		return response()->json(['data' => $building,'status'=>1,'message' => "Successfully get building."] , 200);
    	}else{
    		$building = Building::all(['id','society_id','name']);
    		return response()->json(['data' => $building,'status'=>1,'message' => "Successfully get building."] , 200);
    	}
    }

    public function getflat(Request $request)
    {
    	$building = request('building_id');
    	if($building){
    		$flat = Flat::select('id','building_id','name')->where('building_id', $building)->get();
    		return response()->json(['data' => $flat,'status'=>1,'message' => "Successfully get area."] , 200);
    	}else{
    		$flat = Flat::all(['id','building_id','name']);
    		return response()->json(['data' => $flat,'status'=>1,'message' => "Successfully get area."] , 200);
    	}
    }

    public function getflat2(Request $request)
    {
        $building = request('building_id');
        $society_id = request('society_id');
        if($building){
            $pp =  DB::table('flats')
            ->leftjoin('buildings', 'flats.building_id', '=', $building )
            ->leftjoin('buildings', 'buildings.society_id', '=', $society_id )->get();
            dd($pp);
            // $flat = Flat::select('id','building_id','name')->where('building_id', $building)->get();
            return response()->json(['data' => $flat,'status'=>1,'message' => "Successfully get area."] , 200);
        }else{
            $flat = Flat::all(['id','building_id','name']);
            return response()->json(['data' => $flat,'status'=>1,'message' => "Successfully get area."] , 200);
        }
    }

    
    
    
}
