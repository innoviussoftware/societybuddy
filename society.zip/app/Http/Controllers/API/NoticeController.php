<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Notice;
use App\Member;
use App\User;
use App\Society;
use Auth;
use Validator;
use App\Helpers\Notification\PushNotification;

class NoticeController extends Controller
{
    
	public function addnotice(Request $request)
	{
		  $validator = Validator::make($request->all(),[
           'society_id'  => 'required',
           'building_id'  => 'required',
          // 'user_id' => 'required',
           'title'  => 'required',
           'description'=>'required',
           'view_till'=>'required',
    	]);

    	if ($validator->fails()) {
            $errorMessage = implode(',', $validator->errors()->all());
            return response()->json(['data' => $errorMessage,'status'=>0,'message' => "Please enter valid data."] , 200);
            //return response()->json(['errors' => $errorMessage], 422);
      }else
      {
          $user_id=auth()->user()->id;

        	$notice=new Notice();
        	$notice->society_id=request('society_id');
        	$notice->building_id=request('building_id');
        	$notice->user_id=$user_id;
        	$notice->title=request('title');
        	$notice->description=request('description');
        	$notice->view_till=request('view_till');
        	$notice->save();

          $mysqlvalue= explode(",",request('building_id'));
          $token=[];
          foreach ($mysqlvalue as $value) 
          {
              $members=Member::where('building_id',$value)->where('society_id',request('society_id'))->get();

              foreach ($members as $value) {

                  $users=User::where('id',$value->user_id)->first();
                  $token[]=$users->fcm_token;  
              }
          }

          $device_id=$token;

          $societyName=Society::where('id',request('society_id'))->first();

          $pmsg = array(
                'body' => request('description'),
                'title' => request('title'),
                'icon' => 'myicon',
                'sound' => 'mySound'
          );

          $data=array(
              'notification_type'=>'Notice',
              'title'=>request('title'),
              'description'=>request('description'),
          );

          PushNotification::SendPushNotification($pmsg, $data, $device_id);

          return response()->json(['data' => $notice,'status'=>1,'message' => "Notice Added Successfully."] , 200);

        	
      }
	}

	public function getNotice(Request $request){

		$user_id=auth()->user()->id;
		
		$notice=Notice::where('user_id',$user_id)->get();

    return response()->json(['data' => $notice,'status'=>1,'message' => "Notice Details."] , 200);
	}

  public function editNotice(Request $request)
  {
      $validator = Validator::make($request->all(),[
           'society_id'  => 'required',
           'building_id'  => 'required',
           //'user_id' => 'required',
           'title'  => 'required',
           'description'=>'required',
           'view_till'=>'required',
      ]);

      if ($validator->fails()) {
            $errorMessage = implode(',', $validator->errors()->all());
            return response()->json(['data' => $errorMessage,'status'=>0,'message' => "Please enter valid data."] , 200);
      }else
      {
          $user_id=auth()->user()->id;
          $id=request('notice_id');
          $society_id=request('society_id');
          $building_id=request('building_id');
          $title=request('title');
          $description=request('description');
          $view_till=request('view_till');

          $updateDetails = array(
            'society_id' => $society_id,
            'building_id' => $building_id,
            'user_id' => $user_id,
            'title' => $title,
            'description' => $description,
            'view_till' => $view_till,
          );

          $notice = Notice::where('id', $id)->update($updateDetails);

          $notice = Notice::where('id', $id)->get();
          
          return response()->json(['data' => $notice,'status'=>1,'message' => "Notice Edited Successfully."] , 200);
      }
  }

  public function deleteNotice(Request $request)
  {
      $id=request('notice_id');

      $Notice=Notice::where('id',$id)->delete();

      if($Notice)
      {
          return response()->json(['data' => "1",'status'=>1,'message' => "Notice Deleted SuccessFully."] , 200);
      }
      else
      {
          return response()->json(['data' => "0",'status'=>0,'message' => "Notice Deleted Failed."] , 200);
      }
  }
    
}
