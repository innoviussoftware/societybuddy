<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Circular;
use App\Member;
use App\User;
use App\Society;
use Validator;
use App\Helpers\Notification\PushNotification;

class CircularController extends Controller
{
    //
    public function addcircular(Request $request)
	{
		$validator = Validator::make($request->all(),[
           'society_id'  => 'required',
           'building_id'  => 'required',
           'title' => 'required',
           'description'  => 'required',
           //'user_id'=>'required',
    	]);

    	if ($validator->fails()) {
            $errorMessage = implode(',', $validator->errors()->all());
            return response()->json(['data' => $errorMessage,'status'=>0,'message' => "Please enter valid data."] , 200);
        }else
        {
        	if(request('pdffile'))
            {
                $img = request('pdffile');
                $custom_file_name = 'circular-'.time().'.'.$img->getClientOriginalExtension();
                $events = $img->storeAs('circular', $custom_file_name);
            }
            $user_id=auth()->user()->id;

        	$circular=new Circular();
        	$circular->user_id=$user_id;
        	$circular->society_id=request('society_id');
        	$circular->building_id=request('building_id');
        	$circular->title=request('title');
        	$circular->description=request('description');
        	if(request('pdffile'))
            {
                $circular->pdffile=$events;
            }
        	
        	$circular->save();

            $mysqlvalue= explode(",",request('building_id'));

              $token=[];

              foreach ($mysqlvalue as $value) 
              {
                  $members=Member::where('building_id',$value)->where('society_id',request('society_id'))->get();

                  foreach ($members as $value) {

                      $users=User::where('id',$value->user_id)->first();
                      $token[]=$users->fcm_token;  
                  }
              }

              $device_id=$token;

              $societyName=Society::where('id',request('society_id'))->first();

              $pmsg = array(
                    'body' => request('description'),
                    'title' => request('title'),
                    'icon' => 'myicon',
                    'sound' => 'mySound'
              );

              $data=array(
                  'notification_type'=>'Circular',
                  'title'=>request('title'),
                  'description'=>request('description'),
              );

              PushNotification::SendPushNotification($pmsg, $data, $device_id);


          return response()->json(['data' => $circular,'status'=>1,'message' => "Circular Added Successfully."] , 200);

        }
	}

	public function getCircular(Request $request){

		$user_id=auth()->user()->id;
		
		$Circular=Circular::where('user_id',$user_id)->get();

    return response()->json(['data' => $Circular,'status'=>1,'message' => "Circular Details."] , 200);
		
	}

    public function editCircular(Request $request)
    {
        $validator = Validator::make($request->all(),[
           'society_id'  => 'required',
           'building_id'  => 'required',
           'title' => 'required',
           'description'  => 'required',
          // 'user_id'=>'required',
        ]);

        if ($validator->fails()) {
            $errorMessage = implode(',', $validator->errors()->all());
            return response()->json(['data' => $errorMessage,'status'=>0,'message' => "Please enter valid data."] , 200);
        }else
        {

            if(request('pdffile'))
            {
                $img = request('pdffile');
                $custom_file_name = 'circular-'.time().'.'.$img->getClientOriginalExtension();
                $events = $img->storeAs('circular', $custom_file_name);
            }
            $user_id=auth()->user()->id;
            $id=request('circular_id');
            $society_id=request('society_id');
            $building_id=request('building_id');
            $title=request('title');
            $description=request('description');
            

            if(request('pdffile'))
            {
                    $updateDetails = array(
                        'society_id' => $society_id,
                        'building_id' => $building_id,
                         'user_id' => $user_id,
                        'title' => $title,
                        'description' => $description,
                        'pdffile'=>$events,
                    );
            }
            else
            {
                     $updateDetails = array(
                        'society_id' => $society_id,
                        'building_id' => $building_id,
                         'user_id' => $user_id,
                        'title' => $title,
                        'description' => $description,                        
                    );
            }
           

            $circular=Circular::where('id', $id)->update($updateDetails);

            $circular = Circular::where('id', $id)->get();

            return response()->json(['data' => $circular,'status'=>1,'message' => "Circular Edited Successfully."] , 200);  
        }

    }

    public function deleteCircular(Request $request)
    {
        $id=request('circular_id');

        $circular=Circular::where('id',$id)->delete();

        if($circular)
        {
              return response()->json(['data' => "1",'status'=>1,'message' => "Circular Deleted SuccessFully."] , 200);
        }
        else
        {
              return response()->json(['data' => "0",'status'=>0,'message' => "Circular Deleted Failed."] , 200);
        }
    }
}
