<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Hash;
use App\Role;
use DB;
use Validator;
use Auth;
use App\User;
use App\Member;
use App\Familymember;
use App\Visitor;


class UserController extends Controller
{
    // 1 = Succcess status
    // 0 = Error status

    public function register(Request $request) {
        $validator = Validator::make($request->all(), [
                   'username'  => 'required',
                   //'email'     => 'required|email|unique:users',
                   'phone'  => 'required| min:9 | max:13 | unique:users',
                   'society_id'  => 'required',
                   'building_id'  => 'required',
                   'flat_id'  => 'required',
                   'flatType'  => 'required',
                   // 'city_id'  => 'required',
                   // 'area_id'  => 'required'
        ]);
        if ($validator->fails()) {
            $errorArray = $validator->errors()->all();
           return response()->json(['data' =>(Object) $errorArray,'status'=>0,'message' => "Please enter valid data."] , 200);
        }
        $mobilexist = User::where('phone',request('phone'))->count();
        if($mobilexist){
            $error[] = 'Phone number is already exist.';
           return response()->json(['data' =>(Object) $error,'status'=>0,'message' => "Phone number is already exist."] , 200);
        }
        try {

            $user = User::create([
                'fcm_token' => request('fcm_token'),
                'email' => request('email'),
                'name' => request('username'),
                'society_id' => request('society_id'),
                'password' => Hash::make('user@123'),
                'phone' => request('phone')
            ]);
            if($user->id){

                $users = User::find($user->id);
                $users->attachRole(9);
                $users->role = "Committee Member";
                $users->token = $users->createToken('MyApp')->accessToken;

                $member = new Member;
                $member->user_id = $user->id;
                $member->society_id = request('society_id');
                $member->building_id = request('building_id');
                $member->flat_id = request('flat_id');
                $member->flatType = request('flatType');
                // $member->city_id = request('city_id');
                // $member->area_id = request('area_id');
                $member->profession = request('profession');
                $member->profession_detail = request('profession_detail');
                $member->save();
                return response()->json(['data' => $users,'status'=>1,'message' => "Successfully user create."] , 200);
            }else{
                return response()->json(['data' => "0",'status'=>0,'message' => "User not created"] , 200);
            }
        } catch (Exception $e) {
                return response()->json(['data' => "0",'status'=>0,'message' => "User not created"] , 200);
        }
    }


    public function login_opt(Request $request) {

        $validator = Validator::make($request->all(), [
                   'phone'  => 'required | min:9 | max:13'
        ]);
        if ($validator->fails()) {
            $errorArray = $validator->errors()->all();
            return response()->json(['data' =>(Object) $errorArray,'status'=>0,'message' => "Please enter valid data."] , 200);
        }
        try {
            $phone = request('phone');
            if($phone){
                $is_exist = User::where('phone', $phone)->first();
                if($is_exist){
                    $rolearray = $is_exist->roles->toArray();
                    $rolear = [];
                    foreach ($rolearray as $key => $value) {
                        $rolear[] = $value['display_name'];
                    }
                    $arrayrole =  implode(",",$rolear);
                    $data = [];
                    $data['is_exist'] = "1";
                    $data['role'] = $arrayrole;
                    $data['otp'] = rand(1000,9999);

                    $userTokens = $is_exist->tokens;
                    foreach($userTokens as $token) {
                        $token->delete();
                    }

                    $data['token'] = $is_exist->createToken('MyApp')->accessToken;
                    $user_update = User::whereId($is_exist->id)->update(['fcm_token'=>request('device_id')]);
                    return response()->json(['data' => $data,'status'=>1,'message' => "Successfully get user."] , 200);
                }else{
                    $data = [];
                    $data['is_exist'] = "0";
                    $data['role'] = "Committee Member";
                    $data['otp'] = rand(1000,9999);
                    return response()->json(['data' => $data,'status'=>1, 'message' => "Successfully get user."] , 200);
                }
            }

        } catch (Exception $e) {

        }
    }

    public function me(){
        $user = auth()->user();

        if ($user) {
            $rolearray =  auth()->user()->roles;
            $rolear = [];
            $buildingarray=[];
            $flatarray=[];
            foreach ($rolearray as $key => $value) {
                $rolear[] = $value['display_name'];
            }
            $arrayrole =  implode(",",$rolear);
            $user->role = $arrayrole;
            unset($user->roles);
            unset($user->roles);
            unset($user->roles);

            $buildingarray=$user->member->building->name;
            $flatarray=$user->member->flat->name;
            $user->building=$buildingarray;
            $user->flats=$flatarray;

            unset($user->member);




            return response()->json(['data' => $user,'status'=>1,'message' => "User profile detail."] , 200);
        } else {
             $error[] = 'User not found.';
            return response()->json(['data' =>(Object) $error,'status'=>0,'message' => "User not found."] , 200);
        }
    }


    public function addfamilymember(Request $request){
        $validator = Validator::make($request->all(), [

                  'family_member_phone'  => 'required| min:9 | max:13 | unique:users',

                    'family_member_phone'  => 'required| min:9 | max:13 | unique:users,phone',

                   'family_member_relation'=> 'required',
                   'family_member_name'  => 'required',
                   'family_member_gender'  => 'required',
                   'family_member_dob'  => 'required',
                   'family_member_bloodgroup'  => 'required',
        ]);
        if ($validator->fails()) {
            $errorArray = $validator->errors()->all();
            $message = implode(",",$errorArray);
           return response()->json(['data' => [],'status'=>0,'message' => $message] , 200);
        } else {
          $loggedInUser = auth()->user();
          $user = new User();
          $user->name = request('family_member_name');
          $user->society_id = $loggedInUser->society_id;
          $user->phone = request('family_member_phone');
          $user->password = Hash::make('user@123');
          if ($request->file('family_member_photo')) {
              $image = $request->family_member_photo;
              $path = $image->store('user');
          }
          $user->image = isset($path) ? $path : "";
          $user->save();
          $user->attachRole(9);

          $member = new Member();
          $member->user_id = $user->id;
          $member->society_id = $loggedInUser->member->society_id;
          $member->building_id = $loggedInUser->member->building_id;
          $member->flat_id = $loggedInUser->member->flat_id;
          $member->family_user_id = $loggedInUser->id; //User family
          $member->gender = request('family_member_gender');
          $member->dob = request('family_member_dob');
          $member->bloodgroup = request('family_member_bloodgroup');
          $member->relation = request('family_member_relation');
          $member->save();

          return response()->json(['data' => [],'status'=>1,'message' => "Successfully added family member."] , 200);
        }
    }

    public function getFamilyMember(Request $request){
        // $familyMember=Familymember::where('user_id',Auth::user()->id)->get();
        //
        // return response()->json(['data' => $familyMember,'status'=>1,'message' => "Successfully Get family member."] , 200);
    }

    public function updatefamilymember(Request $request){
        // $validator = Validator::make($request->all(), [
        //            'family_member_relation'=> 'required',
        //            'family_member_name'  => 'required',
        //            'family_member_phone'  => 'required',
        //            'family_member_gender'  => 'required',
        //            'family_member_dob'  => 'required',
        //            'family_member_bloodgroup'  => 'required',
        // ]);
        if ($validator->fails()) {
            $errorArray = $validator->errors()->all();
           return response()->json(['data' =>(Object) $errorArray,'status'=>0,'message' => "Please enter valid data."] , 200);
        }
        // else
        // {
        //     $user_id=auth()->user()->id;
        //     $id=request('id');
        //     $family_member_relation=request('family_member_relation');
        //     $family_member_name=request('family_member_name');
        //     $family_member_phone=request('family_member_phone');
        //     $family_member_gender=request('family_member_gender');
        //     $family_member_dob=request('family_member_dob');
        //     $family_member_bloodgroup=request('family_member_bloodgroup');
        //
        //     if(request('family_member_photo'))
        //     {
        //         $img = request('family_member_photo');
        //         $custom_file_name = 'family_member_photo-'.time().'.'.$img->getClientOriginalExtension();
        //         $visitorprofile = $img->storeAs('family_member_photo', $custom_file_name);
        //     }
        //
        //     if(request('family_member_photo'))
        //     {
        //         $updateDetails = array(
        //             'family_member_relation' => $family_member_relation,
        //             'family_member_name' => $family_member_name,
        //             'family_member_phone' => $family_member_phone,
        //             'family_member_gender' => $family_member_gender,
        //             'family_member_dob' => $family_member_dob,
        //             'family_member_bloodgroup' => $family_member_bloodgroup,
        //             'family_member_photo'=>$visitorprofile
        //         );
        //
        //     }
        //     else
        //     {
        //         $updateDetails = array(
        //             'family_member_relation' => $family_member_relation,
        //             'family_member_name' => $family_member_name,
        //             'family_member_phone' => $family_member_phone,
        //             'family_member_gender' => $family_member_gender,
        //             'family_member_dob' => $family_member_dob,
        //             'family_member_bloodgroup' => $family_member_bloodgroup,
        //         );
        //     }
        //
        //
        //     $familymember = Familymember::where('id', $id)->update($updateDetails);
        //
        //     $familymember = Familymember::where('id', $id)->get();
        //
        //     return response()->json(['data' => $familymember,'status'=>1,'message' => "Successfully Edited familymember."] , 200);
        // }
    }

    public function GuestList(Request $request)
    {
        $user_id=Auth::user()->id;

        $member=Member::where('user_id',$user_id)->first();

        $flat_id=$member->flat_id;

        $GuestList=Visitor::where('flat_id',$flat_id)->get();

        return response()->json(['data' => $GuestList,'status'=>1,'message' => "Successfully GuestList."] , 200);
    }

    public function logout(Request $request)
    {
        $user_id=request('user_id');

        $user=User::whereId($user_id)->update(['fcm_token'=>'']);

        return response()->json(['data' => '[]','status'=>1,'message' => "Successfully logout."] , 200);
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();

        $validator = Validator::make($request->all(), [
                'email' => 'required',
        ]);

        if ($validator->fails()) {
            $errorArray = $validator->errors()->all();
           return response()->json(['data' =>(Object) $errorArray,'status'=>0,'message' => "Please enter valid data."] , 200);
        }
        else
        {
            $file = $request->file('profile');

            if ($file)
            {
                    $path = $file->store('user_profile');
                    $user->image = isset($path) ? $path : null;
            }

            if (request('email')) {
                    $user->email = request('email');
            }

            if (request('phone')) {
                    $user->phone = request('phone');
            }

            if (request('roles')) {
                $str_arr = preg_split ("/\,/", request('roles'));
                $user->roles()->sync($str_arr); // ex. ['9','5']
            }

            $member=Member::where('user_id',$user->id)->first();

            if (request('profession')) {
                    $member->profession = request('profession');
            }

            if (request('profession_detail')) {
                    $member->profession_detail = request('profession_detail');
            }

            if (request('bloodgroup')) {
                    $member->bloodgroup = request('name');
            }

            if (request('flattype')) {
                    $member->flatType = request('flattype');
            }

            $user->save();

            $member->save();

            return response()->json(['data' => '[]','status'=>1,'message' => "Profile update successfully."] , 200);
        }


    }
}
