<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Guard;
use App\Visitor;
use App\Society;
use App\Building;
use App\Flat;
use App\Member;
use App\User;
use App\InviteGuest;
use Auth;
use Validator;
use Laravel\Passport\Token;
use App\Helpers\Notification\PushNotification;

class GuardController extends Controller
{
    //

    public function guardlogin(Request $request)
    {
    	$validator = Validator::make($request->all(),[
           'login_pin'  => 'required',
    	]);

    	if ($validator->fails()) {
            $errorMessage = implode(',', $validator->errors()->all());
            return response()->json(['errors' => $errorMessage], 422);
        }else
        {
        	$Guard=Guard::where('login_pin',request('login_pin'))->first();
        
        	if($Guard != null)
        	{
                $guard=Guard::whereId($Guard->id)->update(['fcm_token'=>request('device_id')]);

                $guard=Guard::whereId($Guard->id)->get();
                  
        		$guard=array(                
	                'isGuard'=>'1',
	                'guard_list'=>$guard
            	);
                return response()->json(['data' => $guard,'status'=>1,'message' => "Successfully get Guard."] , 200);
        	}
        	else
        	{
        		$guard=array(                
	                'isGuard'=>'0',
	                'guard_list'=>[],
            	);
                return response()->json(['data' =>$guard,'status'=>0,'message' => "Guard Not Available"] , 200);
        	}

        }
    }

    public function addguestentry(Request $request)
    {
    	$guard_id=request('guard_id');

    	$society_id=request('society_id');

        $building_id=request('building_id');

        $flat_id=request('flat_id');

        $profile=request('profile');

        $guest_name=request('guest_name');
       
        if(request('profile'))
        {
                $img = request('profile');
                $custom_file_name = 'visitorprofile-'.time().'.'.$img->getClientOriginalExtension();
                $visitorprofile = $img->storeAs('visitorprofile', $custom_file_name);
        }

        $visitor=new Visitor();
        $visitor->guard_id=$guard_id;
        $visitor->society_id=$society_id;
        $visitor->building_id=$building_id;
        $visitor->flat_id=$flat_id;
        $visitor->name=$guest_name;
        $visitor->photos=isset($visitorprofile)?$visitorprofile:'';
        $visitor->save();
        $visitor->flats;
        $visitor->building;
        $visitor->society;
        $visitor->flats_users;
        $insertedId = $visitor->id;

        $userdeviceid=Member::where('flat_id',$flat_id)->first();

        $membername=[];
        $membername=isset($userdeviceid->name)?$userdeviceid->name:"";
        $visitor->membername=$membername;

        $DeviceId=User::where('id',isset($userdeviceid->user_id)?$userdeviceid->user_id:'')->first();

        $token=isset($DeviceId->fcm_token)?$DeviceId->fcm_token:'';
        
        $societyName=Society::where('id',$society_id)->first();

        $buildingName=Building::where('id',$building_id)->first();

        $flatName=Flat::where('id',$flat_id)->first();

        $pmsg = array(
                'body' => 'Security alert',
                'title' => $societyName->name,
                'icon' => 'myicon',
                'sound' => 'mySound'
        );

        $data=array(
            'notification_type'=>'security',
            'guest_name'=>$guest_name,
            'guest_image'=>isset($visitorprofile)?$visitorprofile:'',
            'flat_no'=>isset($flatName->name)?$flatName->name:'',
            'building_no'=>isset($buildingName->name)?$buildingName->name:'',
            'socity_name'=>isset($societyName->name)?$societyName->name:'',
            'guest_id'=>$insertedId
        );

        PushNotification::SendPushNotification($pmsg, $data, [$token]);

        return response()->json(['data' => $visitor,'status'=>1,'message' => "Visitor added."] , 200);
        

    }

    public function acceptorreject(Request $request)
    {
        $type=request('type');
        
        $guest_id=request('guest_id');

        //1-Accept 2-Reject

        if($type=='1')
        {
                $Visitor=Visitor::where('id',$guest_id)->update(['flag'=>1]);

                $Visitor=Visitor::where('id',$guest_id)->first();

                $guard=Guard::where('id',$Visitor->guard_id)->first();

                $token=$guard->fcm_token;

                $societyName=Society::where('id',$Visitor->society_id)->first();

                $buildingName=Building::where('id',$Visitor->building_id)->first();

                $flatName=Flat::where('id',$Visitor->flat_id)->first();

                $userid=Member::where('flat_id',$Visitor->flat_id)->with('user')->first();

                $ownerName=$userid->user->name;

                $pmsg = array(
                    'body' => 'Security alert',
                    'title' => $societyName->name,
                    'icon' => 'myicon',
                    'sound' => 'mySound'
                );

                $data=array(
                    'notification_type'=>'security',
                    'guest_name'=>$Visitor->name,
                    'guest_image'=>$Visitor->photos,
                    'flat_no'=>isset($flatName->name)?$flatName->name:'',
                    'building_no'=>isset($buildingName->name)?$buildingName->name:'',
                    'socity_name'=>isset($societyName->name)?$societyName->name:'',
                    'visitor_id'=>$Visitor->id,
                    'flag'=>'accepted',
                    'ownername'=>isset($ownerName)?$ownerName:''
                );

                PushNotification::SendPushNotification($pmsg, $data, [$token]);


                return response()->json(['data' => $Visitor,'status'=>1,'message' => "Request accepted."] , 200);
        }   

        if($type=='2')
        {
                $Visitor=Visitor::where('id',$guest_id)->update(['flag'=>2]);

                $Visitor=Visitor::where('id',$guest_id)->first();

                $guard=Guard::where('id',$Visitor->guard_id)->first();

                $token=$guard->fcm_token;

                $societyName=Society::where('id',$Visitor->society_id)->first();

                $buildingName=Building::where('id',$Visitor->building_id)->first();

                $flatName=Flat::where('id',$Visitor->flat_id)->first();

                $userid=Member::where('flat_id',$Visitor->flat_id)->with('user')->first();

                $ownerName=$userid->user->name;

                $pmsg = array(
                    'body' => 'Security alert',
                    'title' => $societyName->name,
                    'icon' => 'myicon',
                    'sound' => 'mySound'
                );

                $data=array(
                    'notification_type'=>'security',
                    'guest_name'=>$Visitor->name,
                    'guest_image'=>$Visitor->photos,
                    'flat_no'=>isset($flatName->name)?$flatName->name:'',
                    'building_no'=>isset($buildingName->name)?$buildingName->name:'',
                    'socity_name'=>isset($societyName->name)?$societyName->name:'',
                    'visitor_id'=>$Visitor->id,
                    'flag'=>'rejected',
                    'ownername'=>isset($ownerName)?$ownerName:''
                );

                PushNotification::SendPushNotification($pmsg, $data, [$token]);

                return response()->json(['data' => $Visitor,'status'=>1,'message' => "Request rejected."] , 200);
        }        
    }

    public function emailExists(Request $request)
    {
        $validator = Validator::make($request->all(), [
           'email' => 'required|email|unique:users',
         ]);

        if ($validator->fails()) {
            $errorMessage = implode(',', $validator->errors()->all());
            return response()->json(['errors' => $errorMessage], 422);
        }
        else
        {
            return response()->json(['success' =>'Email Available'], 200);
        }
    }

    public function currentVisitorList(Request $request)
    {
        $guard_id=request('guard_id');

        $Visitor=Visitor::where('guard_id',$guard_id)->where('flag',1)->where('inOutFlag','!=',2)->with('flats','building')->get();

        return response()->json(['data' => $Visitor,'status'=>1,'message' => "Current Visitor List."] , 200);
    }

    public function InoutVisitor(Request $request)
    {
        $type=request('type');

        $id=request('id');

        // 1-In  
        // 2-Out

        if($type=='1')
        {
            $Visitor=Visitor::where('id',$id)->update(['inOutFlag'=>1,'intime'=>request('intime')]);

            $Visitor=Visitor::where('id',$id)->get();

            return response()->json(['data' => $Visitor,'status'=>1,'message' => "Visitor Entered."] , 200);
        }

        if($type=='2')
        {
            $Visitor=Visitor::where('id',$id)->update(['inOutFlag'=>2,'outtime'=>request('outtime')]);

            $Visitor=Visitor::where('id',$id)->get();

            return response()->json(['data' => $Visitor,'status'=>1,'message' => "Visitor Exited."] , 200);
        }
    }

    public function guardLogout(Request $request)
    {
        $guard_id=request('guard_id');

        $user=Guard::whereId($guard_id)->update(['fcm_token'=>'']);

        return response()->json(['data' => '[]','status'=>1,'message' => "Successfully logout."] , 200);
    }

    public function addFrequentEntry(Request $request)
    {
        $validator = Validator::make($request->all(), [
                   'society_id'  => 'required',
                   'frequency'=> 'required',
                   'start_date'  => 'required',
                   'end_date'  => 'required',
                   'contact_name'  => 'required',
                   'contact_number'  => 'required',
        ]);
        if ($validator->fails()) {
            $errorArray = $validator->errors()->all();
           return response()->json(['data' =>(Object) $errorArray,'status'=>0,'message' => "Please enter valid data."] , 200);
        }else
        {
                $userId = auth()->user()->id;
                $visitor=new InviteGuest();
                $visitor->user_id=$userId;
                $visitor->society_id=request('society_id');
                $visitor->frequency=request('frequency');
                $visitor->start_date=request('start_date');
                $visitor->end_date=request('end_date');
                $visitor->contact_name=request('contact_name');
                $visitor->contact_number=request('contact_number');
                $visitor->save();

                return response()->json(['data' => $visitor,'status'=>1,'message' => "Successfully Added."] , 200);

        }
    }

    public function allvisitorList(Request $request)
    {
        $guard_id=request('guard_id');

        $Visitor=Visitor::where('guard_id',$guard_id)->where('flag',1)->with('flats','building')->get();

        return response()->json(['data' => $Visitor,'status'=>1,'message' => "All Visitor List."] , 200);
    }

}
