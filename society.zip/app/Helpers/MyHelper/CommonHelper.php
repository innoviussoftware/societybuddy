<?php

namespace App\Helpers\MyHelper;

use Illuminate\Support\Facades\DB;
use App\Job;

class CommonHelper
{
    protected static $_master_setting;

        
}
